
                    import {readFileSync} from 'fs';
                    
                    // Calling the readFileSync() method
                    // to read 'input.txt' file
                    import * as path from 'path';
                    function retrieveFileContents(relativeFilePath: string): string {
                      const filePath = path.resolve(__dirname, relativeFilePath);
                      return readFileSync(filePath, {encoding: 'utf8', flag: 'r'});
                    }
                    const mockVideoContentsGroupHtml = retrieveFileContents(
                      './mock-video-contents-group.html',
                    );
                    
                            test("get ids from html",  () => {
                                let x = 5
                                console.log(mockVideoContentsGroupHtml.slice(1,5));
                                expect(x).toBe(6)
                            });
                    
                    