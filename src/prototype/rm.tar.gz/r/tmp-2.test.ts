import {readFileSync} from 'fs';
import * as path from 'path';
function retrieveFileContents(relativeFilePath: string): string {
  const filePath = path.resolve(__dirname, relativeFilePath);
  return readFileSync(filePath, {encoding: 'utf8', flag: 'r'});
}
const mockVideoContentsGroupHtml = retrieveFileContents(
  './mock-video-contents-group.html',
);

test('get ids from html', () => {
  const mockVideoJSON = retrieveFileContents('./mock-ids-1.json');
  const expectedIds = JSON.parse(mockVideoJSON).ids;
  expect(extractAllRecommendations(mockVideoContentsGroupHtml)).toStrictEqual(
    expectedIds,
  );
});
